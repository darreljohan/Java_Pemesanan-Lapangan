/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author darre
 */
public class Lapangan {
    protected String idLapangan;
    protected String namaLapangan;
    protected int panjangLapangan;
    protected int lebarLapangan;
    protected String jenisLapangan;
    protected int hargaJam;

    public Lapangan() {
    }

    public String getIdLapangan() {
        return idLapangan;
    }

    public void setIdLapangan(String idLapangan) {
        this.idLapangan = idLapangan;
    }

    public String getNamaLapangan() {
        return namaLapangan;
    }

    public void setNamaLapangan(String namaLapangan) {
        this.namaLapangan = namaLapangan;
    }

    public int getPanjangLapangan() {
        return panjangLapangan;
    }

    public void setPanjangLapangan(int panjangLapangan) {
        this.panjangLapangan = panjangLapangan;
    }

    public int getLebarLapangan() {
        return lebarLapangan;
    }

    public void setLebarLapangan(int lebarLapangan) {
        this.lebarLapangan = lebarLapangan;
    }

    public String getJenisLapangan() {
        return jenisLapangan;
    }

    public void setJenisLapangan(String jenisLapangan) {
        this.jenisLapangan = jenisLapangan;
    }

    public int getHargaJam() {
        return hargaJam;
    }

    public void setHargaJam(int hargaJam) {
        this.hargaJam = hargaJam;
    }

    
    
    
}
